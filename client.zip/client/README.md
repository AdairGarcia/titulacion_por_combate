# Frontend
This is the frontend of the project. It is built using ReactJS. 

### Getting Started
``` Initialize the project
ensure you are in the client directory
> cd client
now run the following commands
> npm i
> npm i fs-extra
> npm install react-icons
> npm run dev
