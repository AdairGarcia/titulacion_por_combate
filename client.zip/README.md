# Titulacion-por-combate 
The project is a web application that allows users to 
create and manage their own forms.
This forms can be downloaded as a txt file and 
uploaded to the "Titulacion por combate" game to be visualized. 

The application is built using the MERN stack (MongoDB, Express, React, Node.js).
***
## Table of Contents
1. [Frontend](client/README.md)
2. [Backend](#backend)
***

# Backend
This project was generated with nodejs v22.12.0

### Getting Started
``` Initialize the project
ensure you are in the server directory
turn on mongodb
> mongod
now run the following command
> npm run dev
